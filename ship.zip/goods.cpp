//
// Created by xinya on 2024/3/15.
//
#include "goods.h"
std::allocator<Grid> Goods::grid_allocator{};