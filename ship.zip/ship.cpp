//
// Created by xinya on 2024/3/8.
//

#include "ship.h"
int Ship::capacity = 0;
